import { Component } from '@angular/core';

@Component({
  selector: 'app-contactinfo',
  standalone: true,
  imports: [],
  templateUrl: './contactinfo.component.html',
  styleUrl: './contactinfo.component.css'
})
export class ContactinfoComponent {

}
