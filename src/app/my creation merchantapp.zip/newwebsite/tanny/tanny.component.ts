import { Component } from '@angular/core';

@Component({
  selector: 'app-tanny',
  standalone: true,
  imports: [],
  templateUrl: './tanny.component.html',
  styleUrl: './tanny.component.css'
})
export class TannyComponent {

}
