import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NewwebsiteRoutingModule } from './newwebsite-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    NewwebsiteRoutingModule
  ]
})
export class NewwebsiteModule { }
